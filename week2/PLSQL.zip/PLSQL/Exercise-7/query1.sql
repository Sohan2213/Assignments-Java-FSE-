CREATE OR REPLACE PACKAGE BODY CustomerManagement AS

    PROCEDURE AddCustomer(p_customer_id IN NUMBER, p_name IN VARCHAR2, p_dob IN DATE, p_address IN VARCHAR2) IS
    BEGIN
        INSERT INTO Customers (customer_id, name, dob, address)
        VALUES (p_customer_id, p_name, p_dob, p_address);
        DBMS_OUTPUT.PUT_LINE('Customer added successfully.');
    EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
            DBMS_OUTPUT.PUT_LINE('Error: Customer ID already exists.');
    END AddCustomer;

    PROCEDURE UpdateCustomerDetails(p_customer_id IN NUMBER, p_name IN VARCHAR2, p_dob IN DATE, p_address IN VARCHAR2) IS
    BEGIN
        UPDATE Customers
        SET name = p_name, dob = p_dob, address = p_address
        WHERE customer_id = p_customer_id;
        DBMS_OUTPUT.PUT_LINE('Customer details updated successfully.');
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            DBMS_OUTPUT.PUT_LINE('Error: Customer ID not found.');
    END UpdateCustomerDetails;

    FUNCTION GetCustomerBalance(p_customer_id IN NUMBER) RETURN NUMBER IS
        v_balance NUMBER;
    BEGIN
        SELECT SUM(balance)
        INTO v_balance
        FROM Accounts
        WHERE customer_id = p_customer_id;
        
        RETURN v_balance;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RETURN 0;
    END GetCustomerBalance;

END CustomerManagement;
/
