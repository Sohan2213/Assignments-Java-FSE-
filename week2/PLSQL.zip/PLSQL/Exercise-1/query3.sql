DECLARE
    CURSOR loan_cursor IS
        SELECT customer_id, due_date
        FROM loans
        WHERE due_date BETWEEN SYSDATE AND SYSDATE + 30;
    
    v_customer_id loans.customer_id%TYPE;
    v_due_date loans.due_date%TYPE;
BEGIN
    FOR loan_record IN loan_cursor LOOP
        v_customer_id := loan_record.customer_id;
        v_due_date := loan_record.due_date;

        -- Print reminder message
        DBMS_OUTPUT.PUT_LINE('Reminder: Customer ID ' || v_customer_id || ' has a loan due on ' || TO_CHAR(v_due_date, 'YYYY-MM-DD') || '.');
    END LOOP;
END;
/
