DECLARE
    CURSOR customer_cursor IS
        SELECT customer_id, age, loan_interest_rate
        FROM customers
        WHERE age > 60;
    
    v_customer_id customers.customer_id%TYPE;
    v_age customers.age%TYPE;
    v_loan_interest_rate customers.loan_interest_rate%TYPE;
BEGIN
    FOR customer_record IN customer_cursor LOOP
        v_customer_id := customer_record.customer_id;
        v_age := customer_record.age;
        v_loan_interest_rate := customer_record.loan_interest_rate;
        
        v_loan_interest_rate := v_loan_interest_rate - 1;

        UPDATE customers
        SET loan_interest_rate = v_loan_interest_rate
        WHERE customer_id = v_customer_id;
        
        DBMS_OUTPUT.PUT_LINE('Updated loan interest rate for customer ID: ' || v_customer_id);
    END LOOP;
    
    COMMIT;
END;
/
