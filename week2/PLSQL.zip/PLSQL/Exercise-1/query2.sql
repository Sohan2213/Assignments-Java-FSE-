DECLARE
    CURSOR customer_cursor IS
        SELECT customer_id, balance
        FROM customers
        WHERE balance > 10000;
    
    v_customer_id customers.customer_id%TYPE;
    v_balance customers.balance%TYPE;
BEGIN
    FOR customer_record IN customer_cursor LOOP
        v_customer_id := customer_record.customer_id;
        v_balance := customer_record.balance;

        -- Set IsVIP flag to TRUE
        UPDATE customers
        SET is_vip = 'TRUE'
        WHERE customer_id = v_customer_id;
        
        DBMS_OUTPUT.PUT_LINE('Customer ID: ' || v_customer_id || ' promoted to VIP status.');
    END LOOP;
    
    COMMIT;
END;
/
