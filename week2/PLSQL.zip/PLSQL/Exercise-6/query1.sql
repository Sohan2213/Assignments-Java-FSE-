DECLARE
    CURSOR transaction_cursor IS
        SELECT customer_id, transaction_id, amount, transaction_date
        FROM Transactions
        WHERE EXTRACT(MONTH FROM transaction_date) = EXTRACT(MONTH FROM SYSDATE)
        AND EXTRACT(YEAR FROM transaction_date) = EXTRACT(YEAR FROM SYSDATE);
    
    v_customer_id Transactions.customer_id%TYPE;
    v_transaction_id Transactions.transaction_id%TYPE;
    v_amount Transactions.amount%TYPE;
    v_transaction_date Transactions.transaction_date%TYPE;
BEGIN
    OPEN transaction_cursor;
    LOOP
        FETCH transaction_cursor INTO v_customer_id, v_transaction_id, v_amount, v_transaction_date;
        EXIT WHEN transaction_cursor%NOTFOUND;
        
        DBMS_OUTPUT.PUT_LINE('Customer ID: ' || v_customer_id);
        DBMS_OUTPUT.PUT_LINE('Transaction ID: ' || v_transaction_id);
        DBMS_OUTPUT.PUT_LINE('Amount: ' || v_amount);
        DBMS_OUTPUT.PUT_LINE('Date: ' || TO_CHAR(v_transaction_date, 'DD-MON-YYYY'));
        DBMS_OUTPUT.PUT_LINE('--------------------------------------');
    END LOOP;
    CLOSE transaction_cursor;
END;
/
