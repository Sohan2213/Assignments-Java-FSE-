DECLARE
    CURSOR loan_cursor IS
        SELECT loan_id, interest_rate
        FROM Loans;

    v_loan_id Loans.loan_id%TYPE;
    v_interest_rate Loans.interest_rate%TYPE;
    v_new_interest_rate Loans.interest_rate%TYPE;
BEGIN
    OPEN loan_cursor;
    LOOP
        FETCH loan_cursor INTO v_loan_id, v_interest_rate;
        EXIT WHEN loan_cursor%NOTFOUND;
        
        v_new_interest_rate := v_interest_rate + 0.5;
        
        UPDATE Loans
        SET interest_rate = v_new_interest_rate
        WHERE loan_id = v_loan_id;
        
        DBMS_OUTPUT.PUT_LINE('Updated Loan ID: ' || v_loan_id || ' with new Interest Rate: ' || v_new_interest_rate);
    END LOOP;
    CLOSE loan_cursor;
    
    COMMIT;
END;
/
