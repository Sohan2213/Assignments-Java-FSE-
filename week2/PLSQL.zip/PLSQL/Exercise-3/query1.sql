CREATE OR REPLACE PROCEDURE ProcessMonthlyInterest
IS
    v_interest_rate CONSTANT NUMBER := 0.01;
BEGIN
    UPDATE accounts
    SET balance = balance * (1 + v_interest_rate)
    WHERE account_type = 'SAVINGS';

    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        RAISE;
END ProcessMonthlyInterest;
/
