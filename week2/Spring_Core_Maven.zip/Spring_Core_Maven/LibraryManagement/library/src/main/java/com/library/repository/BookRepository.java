package com.library.repository;

public class BookRepository {

    public void performSomeOperation() {
        System.out.println("Performing some operation in the repository");
    }
}
