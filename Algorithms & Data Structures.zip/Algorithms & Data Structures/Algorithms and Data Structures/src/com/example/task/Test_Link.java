package com.example.task;

public class Test_Link {
    public static void main(String[] args) {
        Task_Link taskList = new Task_Link();
        taskList.addTask(new Task("T001", "Design System", "Pending"));
        taskList.addTask(new Task("T002", "Implement Feature", "In Progress"));
        taskList.addTask(new Task("T003", "Test Feature", "Completed"));
        System.out.println("All Tasks:");
        taskList.traverseTasks();
        System.out.println("\nSearch for Task with ID 'T002':");
        Task task = taskList.searchTask("T002");
        if (task != null) {
            System.out.println(task);
        } else {
            System.out.println("Task not found.");
        }
        System.out.println("\nDeleting Task with ID 'T002'");
        taskList.deleteTask("T002");
        System.out.println("\nAll Tasks After Deletion:");
        taskList.traverseTasks();
    }
}
