package com.example.inventory;

public class Test_Inventory {
    public static void main(String[] args) {
        Inventory_Mgt ims = new Inventory_Mgt();
        Product product1 = new Product("P001", "Laptop", 10, 1500.0);
        Product product2 = new Product("P002", "Smartphone", 20, 800.0);
        ims.addProduct(product1);
        ims.addProduct(product2);
        
        System.out.println("Initial Inventory:");
        ims.displayAllProducts();
        Product updatedProduct1 = new Product("P001", "Laptop", 15, 1400.0);
        ims.updateProduct("P001", updatedProduct1);
        System.out.println("\nUpdated Inventory:");
        ims.displayAllProducts();
        ims.deleteProduct("P002");
        System.out.println("\nFinal Inventory:");
        ims.displayAllProducts();
    }
}
