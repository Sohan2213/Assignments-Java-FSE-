package com.example.empmng;

public class Test_Employee {
    public static void main(String[] args) {
        Emp_Management ems = new Emp_Management(10);
        ems.addEmployee(new Employee("E001", "Sohan", "Developer", 60000));
        ems.addEmployee(new Employee("E002", "Pratik", "Designer", 55000));
        ems.addEmployee(new Employee("E003", "Chinmayi", "Manager", 80000));
        System.out.println("All Employees:");
        ems.traverseEmployees();
        System.out.println("\nSearch for Employee with ID 'E002':");
        Employee employee = ems.searchEmployee("E002");
        if (employee != null) {
            System.out.println(employee);
        } else {
            System.out.println("Employee not found.");
        }
        System.out.println("\nDeleting Employee with ID 'E002'");
        ems.deleteEmployee("E002");
        System.out.println("\nAll Employees After Deletion:");
        ems.traverseEmployees();
    }
}
