package com.example.search;

public class Test_Search {
    public static void main(String[] args) {
        Product[] products = {
            new Product("1", "Laptop", "Electronics"),
            new Product("2", "Smartphone", "Electronics"),
            new Product("3", "Tablet", "Electronics"),
            new Product("4", "Headphones", "Accessories"),
            new Product("5", "Charger", "Accessories")
        };
        System.out.println("Linear Search:");
        Product result1 = Linear_Search.linearSearch(products, "Tablet");
        System.out.println(result1 != null ? result1 : "Product not found.");
        System.out.println("\nBinary Search:");
        Product result2 = Binary_Search.binarySearch(products, "Tablet");
        System.out.println(result2 != null ? result2 : "Product not found.");
    }
}
