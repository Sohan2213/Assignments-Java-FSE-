package com.example.library;

import java.util.Arrays;
import java.util.List;

public class Test_Book {
    public static void main(String[] args) {
        List<Book> books = Arrays.asList(
                new Book("B001", "The Great Gatsby", "F. Scott Fitzgerald"),
                new Book("B002", "To Kill a Mockingbird", "Harper Lee"),
                new Book("B003", "1984", "George Orwell"),
                new Book("B004", "Pride and Prejudice", "Jane Austen"),
                new Book("B005", "The Catcher in the Rye", "J.D. Salinger")
        );

        Library library = new Library(books);
        System.out.println("Linear Search:");
        Book book = library.linearSearchByTitle("1984");
        if (book != null) {
            System.out.println("Found: " + book);
        } else {
            System.out.println("Book not found.");
        }
        books.sort((b1, b2) -> b1.getTitle().compareToIgnoreCase(b2.getTitle()));

        System.out.println("\nBinary Search:");
        book = library.binarySearchByTitle("1984");
        if (book != null) {
            System.out.println("Found: " + book);
        } else {
            System.out.println("Book not found.");
        }
    }
}
