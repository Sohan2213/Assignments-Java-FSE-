package com.example.price;

import java.util.Arrays;

public class Test_price {
    public static void main(String[] args) {
        Order[] orders = {
            new Order("1", "Sohan", 250.0),
            new Order("2", "Sovan", 100.0),
            new Order("3", "Kartik", 200.0),
            new Order("4", "Dora", 150.0),
            new Order("5", "Rahul", 300.0)
        };

        Order[] bubbleSortedOrders = Arrays.copyOf(orders, orders.length);
        Bubble.bubbleSort(bubbleSortedOrders);
        System.out.println("Bubble Sorted Orders:");
        for (Order order : bubbleSortedOrders) {
            System.out.println(order);
        }

        Order[] quickSortedOrders = Arrays.copyOf(orders, orders.length);
        Quick.quickSort(quickSortedOrders, 0, quickSortedOrders.length - 1);
        System.out.println("\nQuick Sorted Orders:");
        for (Order order : quickSortedOrders) {
            System.out.println(order);
        }
    }
}
