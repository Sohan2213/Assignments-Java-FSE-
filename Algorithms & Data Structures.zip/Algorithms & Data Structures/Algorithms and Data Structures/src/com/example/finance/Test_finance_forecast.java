package com.example.finance;
import java.util.HashMap;
import java.util.Map;

public class Test_finance_forecast {

    private static Map<Integer, Double> memo = new HashMap<>();

    public static double calculateFutureValue(double initialValue, double annualGrowthRate, int years) {
        if (years == 0) {
            return initialValue;
        }
        if (memo.containsKey(years)) {
            return memo.get(years);
        }
        double futureValue = calculateFutureValue(initialValue, annualGrowthRate, years - 1) * (1 + annualGrowthRate);
        memo.put(years, futureValue);
        return futureValue;
    }

    public static void main(String[] args) {
        double initialValue = 1000.0;
        double annualGrowthRate = 0.05; 
        int years = 10;

        double futureValue = calculateFutureValue(initialValue, annualGrowthRate, years);
        System.out.println("Predicted future value after " + years + " years: " + futureValue);
    }
}
