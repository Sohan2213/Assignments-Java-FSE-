package com.bookstore.bookstoreapi.Controller;

import com.bookstore.bookstoreapi.DTO.BookDTO;
import com.bookstore.bookstoreapi.Service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/books")
public class BookController {

    @Autowired
    private BookService bookService;

    @GetMapping
    public List<BookDTO> getAllBooks() {
        return bookService.getAllBooks();
    }

    @GetMapping("/{id}")
    public BookDTO getBookById(@PathVariable Long id) {
        return bookService.getBookById(id);
    }

    @PostMapping
    public void addBook(@RequestBody BookDTO bookDTO) {
        // Code to add new book
    }

    @PutMapping("/{id}")
    public void updateBook(@PathVariable Long id, @RequestBody BookDTO bookDTO) {
        // Code to update existing book
    }

    @DeleteMapping("/{id}")
    public void deleteBook(@PathVariable Long id) {
        // Code to delete book
    }
}

