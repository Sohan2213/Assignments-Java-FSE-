package com.bookstore.bookstoreapi.Controller;

import com.bookstore.bookstoreapi.DTO.CustomerDTO;
import com.bookstore.bookstoreapi.Service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/customers")
public class CustomerController {

    @Autowired
    private CustomerService customerService;

    @GetMapping
    public List<CustomerDTO> getAllCustomers() {
        return customerService.getAllCustomers();
    }

    @GetMapping("/{id}")
    public CustomerDTO getCustomerById(@PathVariable Long id) {
        return customerService.getCustomerById(id);
    }

    @PostMapping
    public void addCustomer(@RequestBody CustomerDTO customerDTO) {
        // Code to add new customer
    }

    @PutMapping("/{id}")
    public void updateCustomer(@PathVariable Long id, @RequestBody CustomerDTO customerDTO) {
        // Code to update customer
    }

    @DeleteMapping("/{id}")
    public void deleteCustomer(@PathVariable Long id) {
        // Code to delete customer
    }
}
