package com.bookstore.bookstoreapi.Controller;

import com.bookstore.bookstoreapi.DTO.BookDTO;
import com.bookstore.bookstoreapi.Service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.util.List;

@RestController
@RequestMapping("/books")
@Tag(name = "Book Controller", description = "Manage books in the bookstore")
public class BookController {

    @Autowired
    private BookService bookService;

    public BookController(BookService bookService) {
        this.bookService = bookService;
    }
    @Operation(summary = "Get all books", description = "Fetches all books from the bookstore")
    @GetMapping(produces = { MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
    public List<BookDTO> getAllBooks() {
        return bookService.getAllBooks();
    }

    @GetMapping("/{id}")
    public BookDTO getBookById(@PathVariable Long id) {
        return bookService.getBookById(id);
    }

    @PostMapping
    public void addBook(@RequestBody BookDTO bookDTO) {
    }

    @PutMapping("/{id}")
    public void updateBook(@PathVariable Long id, @RequestBody BookDTO bookDTO) {
    }

    @DeleteMapping("/{id}")
    public void deleteBook(@PathVariable Long id) {
    }
}

