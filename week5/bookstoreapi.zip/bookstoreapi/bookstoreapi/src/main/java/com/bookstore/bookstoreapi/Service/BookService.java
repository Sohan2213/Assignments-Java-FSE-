package com.bookstore.bookstoreapi.Service;

import com.bookstore.bookstoreapi.DTO.BookDTO;
import com.bookstore.bookstoreapi.entity.Book;
import com.bookstore.bookstoreapi.Repository.BookRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class BookService {
    
    @Autowired
    private BookRepo bookRepository;

    public List<BookDTO> getAllBooks() {
        return bookRepository.findAll().stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    public BookDTO getBookById(Long id) {
        return bookRepository.findById(id).map(this::convertToDTO).orElseThrow(() -> new RuntimeException("Book not found"));
    }

    private BookDTO convertToDTO(Book book) {
        BookDTO dto = new BookDTO();
        dto.setId(book.getId());
        dto.setTitle(book.getTitle());
        dto.setIsbn(book.getIsbn());
        dto.setPrice(book.getPrice());
        dto.setAuthorName(book.getAuthor().getName());
        return dto;
    }
}

