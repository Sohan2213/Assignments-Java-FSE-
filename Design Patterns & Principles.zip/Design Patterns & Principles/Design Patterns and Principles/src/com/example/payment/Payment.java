package com.example.payment;
public interface Payment {
    void processPayment(double amount);
}