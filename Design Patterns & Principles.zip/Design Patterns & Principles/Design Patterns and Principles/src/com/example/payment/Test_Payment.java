package com.example.payment;
public class Test_Payment {
    public static void main(String[] args) {
        PayPal payPal = new PayPal();
        Payment payPalProcessor = new PayPalAdapter(payPal);
        payPalProcessor.processPayment(100.00);
        
        Stripe stripe = new Stripe();
        Payment stripeProcessor = new StripeAdapter(stripe);
        stripeProcessor.processPayment(200.00);

        Square square = new Square();
        Payment squareProcessor = new SquareAdapter(square);
        squareProcessor.processPayment(300.00);
    }
}
