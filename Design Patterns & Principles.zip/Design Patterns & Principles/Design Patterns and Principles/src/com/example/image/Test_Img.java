package com.example.image;
public class Test_Img {
    public static void main(String[] args) {
        Image image1 = new ProxyImg("photo1.jpg");
        Image image2 = new ProxyImg("photo2.jpg");

        image1.display();
        System.out.println();
        image1.display();
        
        System.out.println();
        
        image2.display();
        System.out.println();
        image2.display();
    }
}