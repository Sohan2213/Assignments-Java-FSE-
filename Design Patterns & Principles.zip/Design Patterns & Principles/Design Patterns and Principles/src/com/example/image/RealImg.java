package com.example.image;
public class RealImg implements Image {
    private String fileName;

    public RealImg(String fileName) {
        this.fileName = fileName;
        loadImageFromServer();
    }

    private void loadImageFromServer() {
        System.out.println("Loading " + fileName + " from remote server...");
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void display() {
        System.out.println("Displaying " + fileName);
    }
}