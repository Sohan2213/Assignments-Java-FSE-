package com.example.image;

public class ProxyImg implements Image {
    private String fileName;
    private RealImg realImage;

    public ProxyImg(String fileName) {
        this.fileName = fileName;
    }
    public void display() {
        if (realImage == null) {
            realImage = new RealImg(fileName);
        }
        realImage.display();
    }
}