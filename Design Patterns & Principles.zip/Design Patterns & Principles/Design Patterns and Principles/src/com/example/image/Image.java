package com.example.image;
public interface Image {
    void display();
}