package com.example.student;

public class Test_Student {
    public static void main(String[] args) {
        Student student = new Student("3230", "Sohan", "O");
        View view = new View();
        Controller controller = new Controller(student, view);
        controller.updateView();
        controller.setStudentName("Sovan");
        controller.setStudentId("3229");
        controller.updateView();
    }
}
