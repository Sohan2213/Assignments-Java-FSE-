package com.example.notification;

class SMSNotifierDecorator extends Decorator {
    public SMSNotifierDecorator(Notification note) {
        super(note);
    }

    public void send(String message) {
        super.send(message);
        sendSMS(message);
    }

    private void sendSMS(String message) {
        System.out.println("Sending SMS: " + message);
    }
}

class SlackNotifierDecorator extends Decorator {
    public SlackNotifierDecorator(Notification note) {
        super(note);
    }

    public void send(String message) {
        super.send(message);
        sendSlack(message);
    }

    private void sendSlack(String message) {
        System.out.println("Sending Slack message: " + message);
    }
}
