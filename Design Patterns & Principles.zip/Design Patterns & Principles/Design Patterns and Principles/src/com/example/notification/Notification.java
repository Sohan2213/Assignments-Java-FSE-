package com.example.notification;
public interface Notification {
    void send(String message);
}