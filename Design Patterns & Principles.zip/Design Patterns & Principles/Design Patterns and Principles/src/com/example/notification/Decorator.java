package com.example.notification;
public abstract class Decorator implements Notification {
    protected Notification wrappedNotifier;

    public Decorator(Notification note) {
        this.wrappedNotifier = note;
    }
    
    public void send(String message) {
        wrappedNotifier.send(message);
    }
}