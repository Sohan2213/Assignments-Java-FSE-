package com.example.notification;

public class Email_Notify implements Notification {
    public void send(String message) {
        System.out.println("Sending email: " + message);
    }
}