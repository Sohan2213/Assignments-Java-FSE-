package com.example.notification;

public class Test_Email {
    public static void main(String[] args) {
        Notification emailNotifier = new Email_Notify();
        Notification smsNotifier = new SMSNotifierDecorator(emailNotifier);
        Notification slackNotifier = new SlackNotifierDecorator(smsNotifier);
        slackNotifier.send("Hello! You have a new notification.");
    }
}