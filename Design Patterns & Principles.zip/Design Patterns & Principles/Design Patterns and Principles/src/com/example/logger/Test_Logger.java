package com.example.logger;
public class Test_Logger {

	public static void main(String[] args) {
		Logger log1 = Logger.getInstance();
		Logger log2 = Logger.getInstance();
		
		log1.log("First log");
		log2.log("Second log");
		
		if(log1.equals(log2)) {
			System.out.println("Both logger instances are the same");			
		}
		else {
			System.out.println("Logger instances are different");
		}

	}
}
