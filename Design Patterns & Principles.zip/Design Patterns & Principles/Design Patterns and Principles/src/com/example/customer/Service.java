package com.example.customer;

public class Service {
    private Customer customerRepository;
    public Service(Customer customerRepository) {
        this.customerRepository = customerRepository;
    }
    public String getCustomerDetails(String id) {
        return customerRepository.findCustomerById(id);
    }
}
