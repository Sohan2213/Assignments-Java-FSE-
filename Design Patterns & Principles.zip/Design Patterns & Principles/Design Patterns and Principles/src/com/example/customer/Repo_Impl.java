package com.example.customer;

public class Repo_Impl implements Customer {
    public String findCustomerById(String id) {
        return "Customer with ID: " + id;
    }
}
