package com.example.customer;

public class Test_Customer{
    public static void main(String[] args) {
        Customer repository = new Repo_Impl();
        Service service = new Service(repository);
        String customerDetails = service.getCustomerDetails("12345");
        System.out.println(customerDetails);
    }
}
