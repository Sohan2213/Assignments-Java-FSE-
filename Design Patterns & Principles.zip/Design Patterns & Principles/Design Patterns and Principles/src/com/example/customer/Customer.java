package com.example.customer;

public interface Customer {
    String findCustomerById(String id);
}