package com.example.strategy;

class CreditCardPayment implements Pay_Strategy {
    @SuppressWarnings("unused")
	private String cardNumber;
    @SuppressWarnings("unused")
    private String cardHolderName;
    @SuppressWarnings("unused")
    private String cvv;
    @SuppressWarnings("unused")
    private String expiryDate;

    public CreditCardPayment(String cardNumber, String cardHolderName, String cvv, String expiryDate) {
        this.cardNumber = cardNumber;
        this.cardHolderName = cardHolderName;
        this.cvv = cvv;
        this.expiryDate = expiryDate;
    }
    public void pay(double amount) {
        System.out.println("Paying " + amount + " using Credit Card.");
    }
}

class PayPalPayment implements Pay_Strategy {
	@SuppressWarnings("unused")
    private String email;
	@SuppressWarnings("unused")
    private String password;

    public PayPalPayment(String email, String password) {
        this.email = email;
        this.password = password;
    }
    public void pay(double amount) {
        System.out.println("Paying " + amount + " using PayPal.");
    }
}
