package com.example.strategy;

public class Implement {
    private Pay_Strategy paymentStrategy;

    public void setPaymentStrategy(Pay_Strategy paymentStrategy) {
        this.paymentStrategy = paymentStrategy;
    }

    public void executePayment(double amount) {
        paymentStrategy.pay(amount);
    }
}
