package com.example.strategy;

public class Test_Strat {
    public static void main(String[] args) {
        Implement context = new Implement();

        // Pay using Credit Card
        Pay_Strategy creditCardPayment = new CreditCardPayment("1234567890123456", "John Doe", "123", "12/23");
        context.setPaymentStrategy(creditCardPayment);
        context.executePayment(250.0);

        // Pay using PayPal
        Pay_Strategy payPalPayment = new PayPalPayment("john.doe@example.com", "password123");
        context.setPaymentStrategy(payPalPayment);
        context.executePayment(150.0);
    }
}
