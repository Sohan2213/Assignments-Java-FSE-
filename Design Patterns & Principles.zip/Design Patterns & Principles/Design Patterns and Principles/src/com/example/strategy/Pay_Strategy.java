package com.example.strategy;

public interface Pay_Strategy {
    void pay(double amount);
}
