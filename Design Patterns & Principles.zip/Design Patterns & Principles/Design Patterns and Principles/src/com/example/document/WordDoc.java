package com.example.document;

public class WordDoc extends Document{
	public void open() {
		System.out.println("Opening word...");
	}
	
	public void save() {
		System.out.println("Saving word...");
	}
	
	public void close() {
		System.out.println("Closing word...");
	}
}
