package com.example.document;

public class Test_Document {

	public static void main(String[] args) {
		DocumentFactory wf = new WordDocFactory();
		Document word = wf.create();
		word.open();
		word.save();
		word.close();
		
		DocumentFactory pf = new PdfDocFactory();
		Document pdf = pf.create();
		pdf.open();
		pdf.save();
		pdf.close();
		
		DocumentFactory ef = new ExcelDocFactory();
		Document excel = ef.create();
		excel.open();
		excel.save();
		excel.close();

	}

}
