package com.example.document;

public class ExcelDoc extends Document{
	public void open() {
		System.out.println("Opening excel...");
	}
	
	public void save() {
		System.out.println("Saving excel...");
	}
	
	public void close() {
		System.out.println("Closing excel...");
	}
}
