package com.example.document;

public class PdfDoc extends Document{
	public void open() {
		System.out.println("Opening pdf...");
	}
	
	public void save() {
		System.out.println("Saving pdf...");
	}
	
	public void close() {
		System.out.println("Closing pdf...");
	}
}
