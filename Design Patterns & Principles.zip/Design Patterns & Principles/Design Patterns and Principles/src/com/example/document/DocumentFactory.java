package com.example.document;
public abstract class DocumentFactory {
	public abstract Document create();
}	

class WordDocFactory extends DocumentFactory{
	public Document create() {
		return new WordDoc();
	}
}

class PdfDocFactory extends DocumentFactory{
	public Document create() {
		return new PdfDoc();
	}
}

class ExcelDocFactory extends DocumentFactory{
	public Document create() {
		return new ExcelDoc();
	}
}